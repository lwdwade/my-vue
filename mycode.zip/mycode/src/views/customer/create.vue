<template>
  <prompting-list :is-edit='false'></prompting-list>
</template>

<script>
import PromptingList from './components/PromptingList'

export default {
  name: 'createList',
  components: { PromptingList }
}
</script>
