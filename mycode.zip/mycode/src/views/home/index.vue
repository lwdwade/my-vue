<template>
  <div class="home-container">
    <component :is="currentRole"></component>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import adminhome from './admin'
import editorhome from './editor'

export default {
  name: 'home',
  components: { adminhome, editorhome },
  data() {
    return {
      currentRole: 'adminhome'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  created() {
    if (!this.roles.includes('admin')) {
      this.currentRole = 'editorhome'
    }
  }
}
</script>
