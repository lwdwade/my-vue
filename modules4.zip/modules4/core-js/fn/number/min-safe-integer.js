require('../../modules/es6.number.min-safe-integer');
module.exports = -0x1fffffffffffff;
