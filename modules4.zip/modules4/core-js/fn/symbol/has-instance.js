require('../../modules/es6.function.has-instance');
module.exports = require('../../modules/_wks-ext').f('hasInstance');
