require('../../modules/es7.object.entries');
module.exports = require('../../modules/_core').Object.entries;
