require('../../modules/es6.string.ends-with');
module.exports = require('../../modules/_core').String.endsWith;
