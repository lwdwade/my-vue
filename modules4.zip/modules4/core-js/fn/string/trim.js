require('../../modules/es6.string.trim');
module.exports = require('../../modules/_core').String.trim;
