# babel-helper-explode-assignable-expression

## Usage

TODO
