import * as acorn from 'acorn';
import inject from './inject';

export default inject(acorn);
