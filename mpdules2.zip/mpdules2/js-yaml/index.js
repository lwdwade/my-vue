'use strict';


var yaml = require('./lib/js-yaml.js');


module.exports = yaml;
