/**
* @name Foo
* @class
*/

/**#@+
* @memberOf Foo#
* @field
*/

/**
* @name bar
* @type Object[]
*/

/**#@-*/

/**
* @name Foo2
* @class
*/

/**#@+
* @memberOf Foo2#
* @field
*/

/**
* @name bar
* @type Object[]
*/

/**#@-*/