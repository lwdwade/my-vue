import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/views/layout/Layout'

/** note: submenu only apppear when children.length>=1 **/

/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
*                                if not set alwaysShow, only more than one route under the children
*                                it will becomes nested mode, otherwise not show the root menu
* redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    roles: ['admin','editor']     will control the page roles (you can set multiple roles)
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
    noCache: true                if true ,the page will no be cached(default is false)
  }
**/
export const constantRouterMap = [
  { path: '/login', component: () => import('@/views/login/index'), hidden: true },
  { path: '/404', component: () => import('@/views/errorPage/404'), hidden: true },
  { path: '/401', component: () => import('@/views/errorPage/401'), hidden: true },
  {
    path: '',
    component: Layout,
    redirect: '/home',
    children: [{ path: 'home', component: () => import('@/views/home/index'), name: 'home', meta: { title: 'Home', icon: 'el-icon-menu', noCache: true }}]
  }
]

export default new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

export const asyncRouterMap = [
  {
    path: '/table',
    component: Layout,
    redirect: 'noredirect',
    // hidden: true,
    children: [{ path: 'inline-edit-table', component: () => import('@/views/table/inlineEditTable'), name: 'inlineEditTable', meta: { title: 'inlineEditTable', icon: 'el-icon-location' }}]
  },
  {
    path: '/table',
    component: Layout,
    redirect: 'noredirect',
    // hidden: true,
    children: [{ path: 'complex-table/:id(\\d+)', component: () => import('@/views/table/complexTable'), name: 'complexTable', meta: { title: 'complexTable', icon: 'el-icon-location' }}]
  },
  {
    path: '/error',
    component: Layout,
    redirect: 'noredirect',
    children: [{ path: '401', component: () => import('@/views/errorPage/401'), name: 'page401', meta: { title: 'page401', icon: 'el-icon-close', noCache: true }}]
  },
  {
    path: '/error',
    component: Layout,
    redirect: 'noredirect',
    children: [{ path: '404', component: () => import('@/views/errorPage/404'), name: 'page404', meta: { title: 'page404', icon: 'el-icon-close', noCache: true }}]
  },
  {
    path: '/home',
    component: Layout,
    redirect: 'noredirect',
    children: [{ path: 'cli', component: () => import('@/views/clipboard/index'), name: 'clipboardDemo', meta: { title: 'clipboardDemo', icon: 'el-icon-tickets' }}]
  },
  {
    path: '/customer',
    component: Layout,
    redirect: 'noredirect',
    name: 'customer',
    hidden: false,
    meta: {
      title: 'customer',
      icon: 'el-icon-more'
    },
    children: [
      { path: 'list', component: () => import('@/views/customer/list'), name: 'articleList', meta: { title: 'articleList', icon: 'el-icon-location' }},
      { path: 'create', component: () => import('@/views/customer/create'), name: 'createArticle', meta: { title: 'createArticle', icon: 'el-icon-location' }},
      { path: 'promptinglist/:id(\\d+)', component: () => import('@/views/customer/CustList'), name: 'CustList', meta: { title: 'CustList', icon: 'el-icon-location', noCache: true }, hidden: true }
    ]
  },
  { path: '*', redirect: '/login', hidden: true }
]
