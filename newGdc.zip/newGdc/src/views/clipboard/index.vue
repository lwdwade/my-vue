<template>
  <div class="app-container">
    <el-tabs v-model="activeName">
      <el-tab-pane label="AAAAAAAAAAAAA" name="directly">
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
        <el-input v-model="inputData1" placeholder="Please input" style='width:400px;'></el-input>
      </el-tab-pane>
      <el-tab-pane label="BBBBBBBBBBBBB" name="">
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
        <el-input v-model="inputData2" placeholder="Please input" style='width:600px;'></el-input>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>

export default {
  data() {
    return {
      activeName: 'directly',
      inputData1: 'dfgdfsgdsfgdsfhdsfh',
      inputData2: 'ewrterwtrewywtreuweuwer'
    }
  },
  methods: {

  }
}
</script>
