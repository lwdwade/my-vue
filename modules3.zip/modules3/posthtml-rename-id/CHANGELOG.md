# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="1.0.7"></a>
## [1.0.7](https://github.com/kisenka/svg-mixer/packages/posthtml-rename-id/compare/posthtml-rename-id@1.0.6...posthtml-rename-id@1.0.7) (2018-05-11)




**Note:** Version bump only for package posthtml-rename-id

<a name="1.0.6"></a>
## [1.0.6](https://github.com/kisenka/svg-mixer/packages/posthtml-rename-id/compare/posthtml-rename-id@1.0.5...posthtml-rename-id@1.0.6) (2018-04-28)




**Note:** Version bump only for package posthtml-rename-id

<a name="1.0.5"></a>
## [1.0.5](https://github.com/kisenka/svg-mixer/packages/posthtml-rename-id/compare/posthtml-rename-id@1.0.4...posthtml-rename-id@1.0.5) (2018-04-21)




**Note:** Version bump only for package posthtml-rename-id

<a name="1.0.4"></a>
## [1.0.4](https://github.com/kisenka/svg-baker/packages/posthtml-rename-id/compare/posthtml-rename-id@1.0.4-alpha.0...posthtml-rename-id@1.0.4) (2018-04-13)




**Note:** Version bump only for package posthtml-rename-id

<a name="1.0.4-alpha.0"></a>
## [1.0.4-alpha.0](https://github.com/kisenka/svg-baker/packages/posthtml-rename-id/compare/posthtml-rename-id@1.0.3...posthtml-rename-id@1.0.4-alpha.0) (2018-04-09)




**Note:** Version bump only for package posthtml-rename-id

<a name="1.0.3"></a>
## 1.0.3 (2017-05-16)


### Bug Fixes

* symboId not prepended to clipPath IDs in url(...) ([9e685b4](https://github.com/kisenka/svg-baker/packages/posthtml-rename-id/commit/9e685b4))
