# This module is DEPRECATED. Please use [postsvg](https://www.npmjs.com/package/postsvg) instead.
