# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.1.4"></a>
## [1.1.4](https://github.com/posthtml/posthtml-render/compare/v1.1.3...v1.1.4) (2018-05-11)



<a name="1.1.3"></a>
## [1.1.3](https://github.com/posthtml/posthtml-render/compare/v1.1.2...v1.1.3) (2018-04-04)


### Bug Fixes

* **lib/index:** don't handle `<component>` as self-closing tag ([f958292](https://github.com/posthtml/posthtml-render/commit/f958292))
* **lib/index:** don't handle `<component>` as self-closing tag ([c48a2e2](https://github.com/posthtml/posthtml-render/commit/c48a2e2))



<a name="1.1.2"></a>
## [1.1.2](https://github.com/posthtml/posthtml-render/compare/v1.1.1...v1.1.2) (2018-03-20)



<a name="1.1.1"></a>
## [1.1.1](https://github.com/posthtml/posthtml-render/compare/v1.1.0...v1.1.1) (2018-03-02)
